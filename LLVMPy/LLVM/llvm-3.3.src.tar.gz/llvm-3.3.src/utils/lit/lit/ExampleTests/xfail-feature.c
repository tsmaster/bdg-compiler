// This test should XPASS.

// RUN: true
// XFAIL: some-feature-name
